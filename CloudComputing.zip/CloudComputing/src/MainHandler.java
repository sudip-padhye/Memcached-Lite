import java.util.Random;

public class MainHandler extends Thread {

	private static final int MAX_WAIT_TIME = 3000;
	private static final int NO_OF_CLIENTS = 1000;
	
	public static void main(String[] args) {	
		Random rand = new Random();
		for(int noOfClients=0; noOfClients<NO_OF_CLIENTS; noOfClients++)
		{
			Client client = new Client();
			client.start();
			try {
				Thread.sleep(rand.nextInt(MAX_WAIT_TIME));
			} catch (InterruptedException e) {}
		}
	}
}
