import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Random;
import java.util.Scanner;

public final class Client extends Thread {
	private static final int SERVER_PORT = 10254;
	private static final int MAX_WAIT_TIME = 5000;
	private static String inetAddress;
	private static String[] commandArray = new String[] {
			"abcd",
			"",
			"set indiana 7234567891234567 12 xyz \\r\\nIND \\r\\n",
			"set indiana 7234567891234567 12 3 \\r\\nIND \\r\\n",
			"set cloud 6234567546234567 10 4 \\r\\nabcd \\r\\n",
			"set sice 1234726546234567 0 4 noreply \\r\\ndata \\r\\n",
			"set sudip 5487962145326087 -1 6 noreply \\r\\nserver \\r\\n",
			"add usa 8453012498763054 7 10 \\r\\nwashington \\r\\n",
			"add sice 8453012458796327 3 45 \\r\\nxyz \\r\\n",
			"add france 8453012458741327 50 5 \\r\\nparis \\r\\n",
			"add cloud 8453078558796327 45 3 \\r\\npqr \\r\\n",
			"replace cloud 8453078575296327 38 9 \\r\\ncomputing \\r\\n",
			"replace india 9453078575296327 38 5 \\r\\ndelhi \\r\\n",
			"replace japan 9433078575296327 38 5 \\r\\ntokyo \\r\\n",
			"replace france 8453078575296327 11 38 \\r\\nEiffelTower \\r\\n",
			"append france 4 noreply \\r\\nView \\r\\n",
			"append japan 7 \\r\\nCapital \\r\\n",
			"append cloud 5 \\r\\nClass \\r\\n",
			"append indianapolis 6 noreply \\r\\nRacing \\r\\n",
			"prepend india 4 noreply \\r\\nNEW \\r\\n",
			"prepend sice 8 \\r\\nStudent \\r\\n",
			"prepend usa 4 \\r\\nCity \\r\\n",
			"prepend paris 9 \\r\\nBeautiful \\r\\n",
			"cas sice 1234726546231667 12 4 7234567891234567 \\r\\nHall \\r\\n",
			"cas indiana 1234726546264067 12 8 8234726546234567 \\r\\nHoosiers \\r\\n",
			"cas clouds 1234726546231667 12 6 9624726546234567 \\r\\nAmazon \\r\\n",
			"get indiana\\r\\n",
			"gets cloud india japan",
			"get france indiana sice",
			"gets usa sudip washington\\r\\n",
			"delete cloud \\r\\n",
			"delete indiana noreply \\r\\n",
			"delete tokyo \\r\\n",
			"quit"
	};
	
	Client()
	{
		super(Long.toString(System.nanoTime()));
	}

	public void run()
	{
		String output;
		Scanner sc = new Scanner(System.in);
		Socket clientSocket = null;
		try {
			inetAddress = InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException e1) {
		}
		Random rand = new Random();

		try {
			clientSocket = new Socket(inetAddress, SERVER_PORT);
			DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
			DataInputStream inFromServer = new DataInputStream(clientSocket.getInputStream());
			while (true) {
				int index = rand.nextInt(commandArray.length);
				if (commandArray[index].equalsIgnoreCase("quit"))
				{
					System.out.println("Client at port: "+clientSocket.getLocalPort()+" is closed.");
					return;
				}
				try {
					//long startTime = System.currentTimeMillis();
					outToServer.writeUTF(commandArray[index]);
					output = inFromServer.readUTF();
					//long endTime = System.currentTimeMillis();
					//System.out.println("Server Reponse Time: "+(endTime-startTime)+" milliseconds");
					System.out.println(output);
				} catch (Exception e) {
					System.out.println("SERVER_ERROR <" + e.getMessage() + ">");
				}
				Thread.sleep(rand.nextInt(MAX_WAIT_TIME));
			}
		} catch (Exception e) {
			System.out.println("SERVER_ERROR <" + e.getMessage() + ">");
		}
		sc.close();
	}
}
