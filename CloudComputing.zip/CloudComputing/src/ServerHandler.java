import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.concurrent.ConcurrentHashMap;

public final class ServerHandler extends Thread {

	private DataOutputStream outToClient;
	private DataInputStream inFromClient;
	private String clientCommand;
	private Socket connectionSocket;
	private String sendMessage;
	private String key;
	private String flags;
	@SuppressWarnings("unused")
	private String expTime;
	private int size;
	private String casUnique;
	private String value;
	private boolean noReply;
	private static Map<String, String> keyValueMap = new ConcurrentHashMap<>();
	private static Map<String, String> keyFlagMap = new ConcurrentHashMap<>();
	private static int clientCount;

	ServerHandler(Socket connectionSocket) {
		super(Long.toString(System.nanoTime()));
		this.connectionSocket = connectionSocket;
		this.key = "";
		this.flags = "";
		this.expTime = "";
		this.size = 0;
		this.casUnique = "";
		this.value = "";
		this.noReply = false;
		clientCount++;
	}

	public void run() {
		System.out.println("Client#:" + clientCount + " connected with Thread#:" + Thread.currentThread().getName() + " at " + connectionSocket);
		while (!isInterrupted()) {
			try {
				inFromClient = new DataInputStream(connectionSocket.getInputStream());
				outToClient = new DataOutputStream(connectionSocket.getOutputStream());
				synchronized (this) {
					clientCommand = inFromClient.readUTF();
				}
			} catch (Exception e) {
				sendMessage = "SERVER_ERROR <Server Socket error>\r\n";
				messageTransmitter(sendMessage);
				return;
			}

			int status = 0, status1 = 0;
			try {
				status = fileToMap((ConcurrentHashMap<String, String>) keyValueMap, "data.csv"); // retrieves file data
																									// and puts into map
				status1 = fileToMap((ConcurrentHashMap<String, String>) keyFlagMap, "flags.csv"); // retrieves file data
																									// and puts into map
				if (status == 0 || status1 == 0)
					return;
			} catch (IOException e1) {
			}

			StringTokenizer stringToken = new StringTokenizer(clientCommand);
			String command = null;
			if (stringToken.hasMoreTokens()) {
				command = stringToken.nextToken();
				/* Storage Commands */
				if (command.equals("set")) // "set" means "store this data"
				{
					setValue(stringToken);
					status = fileWrite(keyValueMap, "data.csv"); // writes HashMap to a csv file
					status1 = fileWrite(keyFlagMap, "flags.csv"); // writes HashMap to a csv file
					if (status == 0 || status1 == 0)
						return;
				} else if (command.equals("add")) // "add" means "store this data, but only if the server doesn't
													// already
				// hold
				// data for this key"
				{
					addValue(stringToken);
					status = fileWrite(keyValueMap, "data.csv"); // writes HashMap to a csv file
					status1 = fileWrite(keyFlagMap, "flags.csv"); // writes HashMap to a csv file
					if (status == 0 || status1 == 0)
						return;
				} else if (command.equals("replace")) // "replace" means "store this data, but only if the server does
				// already
				// hold data for this key"
				{
					replaceValue(stringToken);
					status = fileWrite(keyValueMap, "data.csv"); // writes HashMap to a csv file
					status1 = fileWrite(keyFlagMap, "flags.csv"); // writes HashMap to a csv file
					if (status == 0 || status1 == 0)
						return;
				} else if (command.equals("append")) // "append" means "add this data to an existing key after existing
				// data"
				{
					appendValue(stringToken);
					status = fileWrite(keyValueMap, "data.csv"); // writes HashMap to a csv file
					status1 = fileWrite(keyFlagMap, "flags.csv"); // writes HashMap to a csv file
					if (status == 0 || status1 == 0)
						return;
				} else if (command.equals("prepend")) // "prepend" means "add this data to an existing key before
														// existing
				// data"
				{
					prependValue(stringToken);
					status = fileWrite(keyValueMap, "data.csv"); // writes HashMap to a csv file
					status1 = fileWrite(keyFlagMap, "flags.csv"); // writes HashMap to a csv file
					if (status == 0 || status1 == 0)
						return;
				}

				else if (command.equals("cas")) // "cas" is a check and set operation which means "store this data but
												// only if no one else has updated since I last fetched it."
				{
					casValue(stringToken);
					status = fileWrite(keyValueMap, "data.csv"); // writes HashMap to a csv file
					status1 = fileWrite(keyFlagMap, "flags.csv"); // writes HashMap to a csv file
					if (status == 0 || status1 == 0)
						return;
				}

				/* Retrieval Commands */
				else if (command.equals("get") || command.equals("gets")) // the client expects zero or more items, each
																			// of
				// which is received as a text line followed by
				// a
				// data block.
				{
					getValue(stringToken);
				}

				else if (command.equals("delete")) // The command "delete" allows for explicit deletion of items
				{
					deleteValue(stringToken);
					status = fileWrite(keyValueMap, "data.csv"); // writes HashMap to a csv file
					status1 = fileWrite(keyFlagMap, "flags.csv"); // writes HashMap to a csv file
					if (status == 0 || status1 == 0)
						return;
				}

				else {
					sendMessage = "ERROR\r\n";
					messageTransmitter(sendMessage);
				}
			} else {
				sendMessage = "CLIENT_ERROR <Empty Input>\r\n";
				messageTransmitter(sendMessage);
			}

		}
	}

	private synchronized void messageTransmitter(String message) {
		try {
			if (noReply)
				outToClient.writeUTF(" ");
			else
				outToClient.writeUTF(message);
			outToClient.flush();
			noReply = false;
		} catch (IOException e) {
		}
	}

	private void commandReader(String commandType, StringTokenizer stringToken) {
		if (commandType.equals("set") || commandType.equals("add") || commandType.equals("replace")) {
			key = stringToken.nextToken();
			flags = stringToken.nextToken();
			expTime = stringToken.nextToken();
			try {
			size = Integer.parseInt(stringToken.nextToken());
			}catch(Exception e)
			{
				sendMessage = "CLIENT_ERROR <Size is not Integer>\r\n";
				messageTransmitter(sendMessage);
				return;
			}
			String token = stringToken.nextToken();
			value = null;
			if (token.equals("noreply")) {
				noReply = true;
				value = stringToken.nextToken();
				if (value.startsWith("\\r\\n"))
					value = value.substring(4);
			} else {
				if (token.startsWith("\\r\\n"))
					value = token.substring(4);
			}
		} else if (commandType.equals("append") || commandType.equals("prepend")) {
			key = stringToken.nextToken();
			size = Integer.parseInt(stringToken.nextToken());
			String token = stringToken.nextToken();
			value = null;
			if (token.equals("noreply")) {
				noReply = true;
				value = stringToken.nextToken();
				if (value.startsWith("\\r\\n"))
					value = value.substring(4);
			} else {
				if (token.startsWith("\\r\\n"))
					value = token.substring(4);
			}
		} else if (commandType.equals("cas")) {
			key = stringToken.nextToken();
			flags = stringToken.nextToken();
			expTime = stringToken.nextToken();
			size = Integer.parseInt(stringToken.nextToken());
			casUnique = stringToken.nextToken();
			String token = stringToken.nextToken();
			value = null;
			if (token.equals("noreply")) {
				noReply = true;
				value = stringToken.nextToken();
				if (value.startsWith("\\r\\n"))
					value = value.substring(4);
			} else {
				if (token.startsWith("\\r\\n"))
					value = token.substring(4);
			}
		} else if (commandType.equals("delete")) {
			key = stringToken.nextToken();
			if (stringToken.hasMoreTokens()) {
				if (stringToken.nextToken().equals("noreply"))
					noReply = true;
			} else {
				if (key.endsWith("\\r\\n"))
					key = key.substring(0, key.length() - 4);
			}
		}

	}

	private synchronized void setValue(StringTokenizer stringToken) {

		if (clientCommand.contains("noreply"))
			noReply = true;
		
		if (stringToken.countTokens() < 6 || stringToken.countTokens() > 7) // incorrect no. of arguments
		{
			sendMessage = "CLIENT_ERROR <Incorrect No. of Arguments passed>\r\n";
			messageTransmitter(sendMessage);
			return;
		}

		commandReader("set", stringToken);	
		
		if(size==0)
			return;

		if (size != value.length()) // Size of the <value> is not equal to the <bytes>
		{
			sendMessage = "CLIENT_ERROR <size & length of value does not match>\r\n";
			messageTransmitter(sendMessage);
			return;
		}

		if (keyValueMap.get(key) != null) {
			keyValueMap.remove(key);
			keyValueMap.put(key, value);
			keyFlagMap.remove(key);
			keyFlagMap.put(key, flags);
		} else {
			keyValueMap.put(key, value);
			keyFlagMap.put(key, flags);
		}

		sendMessage = "STORED\r\n";
		messageTransmitter(sendMessage);
	}

	private synchronized void addValue(StringTokenizer stringToken) {
		if (clientCommand.contains("noreply"))
			noReply = true;

		if (stringToken.countTokens() < 6 || stringToken.countTokens() > 7) // incorrect no. of arguments
		{
			sendMessage = "CLIENT_ERROR <Incorrect No. of Arguments passed>\r\n";
			messageTransmitter(sendMessage);
			return;
		}

		commandReader("add", stringToken);

		if(size==0)
			return;
		
		if (size != value.length()) // Size of the <value> is not equal to the <bytes>
		{
			sendMessage = "CLIENT_ERROR <size & length of value does not match>\r\n";
			messageTransmitter(sendMessage);
			return;
		}

		if (keyValueMap.get(key) != null) {
			sendMessage = "NOT_ADDED\r\n";
		} else {
			keyValueMap.put(key, value);
			keyFlagMap.put(key, flags);
			sendMessage = "ADDED\r\n";
		}
		messageTransmitter(sendMessage);
	}

	private synchronized void replaceValue(StringTokenizer stringToken) {
		if (clientCommand.contains("noreply"))
			noReply = true;

		if (stringToken.countTokens() < 6 || stringToken.countTokens() > 7) // incorrect no. of arguments
		{
			sendMessage = "CLIENT_ERROR <Incorrect No. of Arguments passed>\r\n";
			messageTransmitter(sendMessage);
			return;
		}

		commandReader("replace", stringToken);

		if(size==0)
			return;
		
		if (size != value.length()) // Size of the <value> is not equal to the <bytes>
		{
			sendMessage = "CLIENT_ERROR <size & length of value does not match>\r\n";
			messageTransmitter(sendMessage);
			return;
		}

		if (keyValueMap.get(key) != null) {
			keyValueMap.remove(key);
			keyValueMap.put(key, value);
			keyFlagMap.remove(key);
			keyFlagMap.put(key, flags);
			sendMessage = "REPLACED\r\n";
		} else {
			sendMessage = "NOT_REPLACED\r\n";
		}
		messageTransmitter(sendMessage);
	}

	private synchronized void appendValue(StringTokenizer stringToken) {
		if (clientCommand.contains("noreply"))
			noReply = true;

		if (stringToken.countTokens() < 4 || stringToken.countTokens() > 5) // incorrect no. of arguments
		{
			sendMessage = "CLIENT_ERROR <Incorrect No. of Arguments passed>\r\n";
			messageTransmitter(sendMessage);
			return;
		}

		commandReader("append", stringToken);

		if(size==0)
			return;
		
		if (size != value.length()) // Size of the <value> is not equal to the <bytes>
		{
			sendMessage = "CLIENT_ERROR <size & length of value does not match>\r\n";
			messageTransmitter(sendMessage);
			return;
		}

		if (keyValueMap.get(key) != null) {
			String oldValue = keyValueMap.get(key);
			keyValueMap.remove(key);
			keyValueMap.put(key, oldValue + value);
			sendMessage = "APPENDED\r\n";
		} else {
			sendMessage = "NOT_APPENDED\r\n";
		}
		messageTransmitter(sendMessage);
	}

	private synchronized void prependValue(StringTokenizer stringToken) {
		if (clientCommand.contains("noreply"))
			noReply = true;

		if (stringToken.countTokens() < 4 || stringToken.countTokens() > 5) // incorrect no. of arguments
		{
			sendMessage = "CLIENT_ERROR <Incorrect No. of Arguments passed>\r\n";
			messageTransmitter(sendMessage);
			return;
		}

		commandReader("prepend", stringToken);

		if(size==0)
			return;
		
		if (size != value.length()) // Size of the <value> is not equal to the <bytes>
		{
			sendMessage = "CLIENT_ERROR <size & length of value does not match>\r\n";
			messageTransmitter(sendMessage);
			return;
		}

		if (keyValueMap.get(key) != null) {
			String oldValue = keyValueMap.get(key);
			keyValueMap.remove(key);
			keyValueMap.put(key, value + oldValue);
			sendMessage = "PREPENDED\r\n";
		} else {
			sendMessage = "NOT_PREPENDED\r\n";
		}
		messageTransmitter(sendMessage);
	}

	private synchronized void casValue(StringTokenizer stringToken) {
		if (clientCommand.contains("noreply"))
			noReply = true;

		if (stringToken.countTokens() < 7 || stringToken.countTokens() > 8) // incorrect no. of arguments
		{
			sendMessage = "CLIENT_ERROR <Incorrect No. of Arguments passed>\r\n";
			messageTransmitter(sendMessage);
			return;
		}

		commandReader("cas", stringToken);

		if(size==0)
			return;
		
		if (size != value.length()) // Size of the <value> is not equal to the <bytes>
		{
			sendMessage = "CLIENT_ERROR <size & length of value does not match>\r\n";
			messageTransmitter(sendMessage);
			return;
		}

		if (keyValueMap.get(key) != null && casUnique.equals(keyFlagMap.get(key))) {
			keyValueMap.remove(key);
			keyValueMap.put(key, value);
			sendMessage = "STORED\r\n";
			messageTransmitter(sendMessage);
		} else if (keyValueMap.get(key) == null) {
			keyValueMap.put(key, value);
			keyFlagMap.put(key, flags);
			sendMessage = "STORED\r\n";
		} else {
			sendMessage = "NOT_STORED\r\n";
		}
		messageTransmitter(sendMessage);
	}

	private void getValue(StringTokenizer stringToken) {
		if (stringToken.countTokens() == 0) {
			sendMessage = "CLIENT_ERROR <Incorrect No. of Arguments passed>\r\n";
			messageTransmitter(sendMessage);
			return;
		}

		String output = "";
		while (stringToken.hasMoreTokens()) {
			String key = stringToken.nextToken();
			if (!stringToken.hasMoreTokens() && key.endsWith("\\r\\n"))
				key = key.substring(0, key.length() - 4);
			String value = keyValueMap.get(key);

			if (value == null) {
				output = output + "CLIENT_ERROR <key: \"" + key + "\" does not exist>\r\n";
			} else {
				int bytes = value.length();
				output = output + "VALUE " + key + " " + keyFlagMap.get(key) + " " + bytes + " " + keyFlagMap.get(key)
						+ " \r\n" + value + "\r\n";
			}
		}
		output = output + "END\r\n";
		messageTransmitter(output);
	}

	private synchronized void deleteValue(StringTokenizer stringToken) {
		if (clientCommand.contains("noreply"))
			noReply = true;

		if (stringToken.countTokens() < 1 || stringToken.countTokens() > 2) // incorrect no. of arguments
		{
			sendMessage = "CLIENT_ERROR <Incorrect No. of Arguments passed>\r\n";
			messageTransmitter(sendMessage);
			return;
		}

		commandReader("delete", stringToken);

		if (keyValueMap.get(key) != null) {
			keyValueMap.remove(key);
			keyFlagMap.remove(key);
			sendMessage = "DELETED\r\n";
		} else {
			sendMessage = "NOT_DELETED\r\n";
		}
		messageTransmitter(sendMessage);
	}

	@SuppressWarnings("resource")
	private synchronized int fileToMap(ConcurrentHashMap<String, String> map, String fileName) throws IOException {

		File file = new File(fileName);

		if (file.exists()) {
			BufferedReader br = null;
			try {
				br = new BufferedReader(new FileReader(fileName));
			} catch (FileNotFoundException e) {
				sendMessage = "SERVER_ERROR <Error in retrieving data from file>\r\n";
				messageTransmitter(sendMessage);
				return 0;
			}
			String line = null;

			try {
				while ((line = br.readLine()) != null) {
					String str[] = line.split("\n");
					for (int i = 0; i < str.length; i++) {
						String arr[] = str[i].split(",");
						map.put(arr[0], arr[1]);
					}
				}
			} catch (Exception e) {
				sendMessage = "SERVER_ERROR <Error in retrieving data from file>\r\n";
				messageTransmitter(sendMessage);
				return 0;
			}
		} else {
			file.createNewFile();
		}
		return 1;
	}

	private synchronized int fileWrite(Map<String, String> map, String fileName) {
		FileWriter csvWriter;
		try {
			csvWriter = new FileWriter(fileName);
			for (String key : map.keySet()) {
				csvWriter.append(key);
				csvWriter.append(",");
				csvWriter.append(map.get(key));
				csvWriter.append("\n");
			}
			csvWriter.close();
		} catch (Exception e) {
			sendMessage = "SERVER_ERROR <Error in storing data to file>\r\n";
			messageTransmitter(sendMessage);
			return 0;
		}
		return 1;
	}

}
