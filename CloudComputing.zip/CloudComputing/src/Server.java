import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public final class Server {
	private static final int LISTENING_PORT = 10254;
	private static ServerSocket serverSocket;

	public static void main(String argv[]) 
	{
		try {
			serverSocket = new ServerSocket(LISTENING_PORT);
		} catch (IOException e1) {
		}
		System.out.println("Server started");
		while (true) {
			try {
				Socket connectionSocket = serverSocket.accept();
				System.out.println("Listening Client Connection");
				ServerHandler serverHandler = new ServerHandler(connectionSocket);
				serverHandler.start();
			} catch (Exception e) {
			}
		}
	}
}